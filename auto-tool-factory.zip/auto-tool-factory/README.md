# 自動ツール工場（auto-tool-factory）

毎朝、AIが新しい計算ツールを1つ考えて安全チェックし、サイトに追加・公開・検索エンジン用の地図（sitemap）更新まで全自動で行うシステムです。広告を設定すれば、ページが増えるほど収益の入口が増えていきます。

## 仕組み
1. `generator/grow.py` … Claude APIが新しいツールをJSONで考案
2. `generator/validate.py` … 数式や形式をチェック。危険なコードや不正確な定義は公開しない
3. `generator/build.py` … 全ツールをHTMLページ化し、トップページ・sitemap.xml・robots.txt・ads.txtを生成
4. `.github/workflows/daily.yml` … 上記を毎朝6時に自動実行し、GitHub Pagesに公開

## 初期設定（1回だけ・約20分）
1. GitHubで新しいリポジトリ `auto-tool-factory` を作り、このフォルダの中身をアップロード
2. `site.json` の `base_url` の `YOUR_NAME` を自分のGitHubユーザー名に書き換える
3. リポジトリの Settings → Pages → Source を「GitHub Actions」にする
4. Settings → Secrets and variables → Actions に `ANTHROPIC_API_KEY`（console.anthropic.com で発行）を登録
5. Actions タブから「毎日ツールを追加して公開」を手動実行して動作確認
6. Google Search Console にサイトを登録し、sitemap.xml を送信
7. ページが20〜30個ほど貯まったら Google AdSense に申請し、承認後 `site.json` の `adsense_client` に `ca-pub-...` を入れる

## 費用
- GitHub Pages：無料
- Claude API：1日1ツールならごく少額（月数十〜百円程度が目安）

## 注意
- 自動生成したページは、ときどき中身を見て間違いがないか確認してください。質の低いページが多いと、AdSenseの審査に落ちたり検索順位が下がったりします
- 独自ドメイン（年1,000〜2,000円ほど）を使うと、AdSenseに通りやすくなります
